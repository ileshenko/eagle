Hi,

The PCB contains five miled (oval) holes.

Please use the big rectangle in the middle of the PCB for manufacturer marks.

See look_me.png file for details.

Thanks,
Igor.